for file in  /media/DATA/Research_code/ImageDatabases/BOSSbase_101/cover/*
do
./S-UNIWARD -h 9 -i $file -O /media/DATA/Research_code/ImageDatabases/BOSSbase_101/S-UNIWARD/005/ -a 0.05
done